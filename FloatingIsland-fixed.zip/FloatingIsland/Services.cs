using System.Globalization;
using System.Net.Http;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace FloatingIsland;

// Общий внешний вид: один и тот же градиент, цвета и анимации для острова и окна настроек.
public static class Look
{
    public static Color C(string s) { try { return (Color)ColorConverter.ConvertFromString(s); } catch { return Colors.White; } }

    public static void Theme(Profile p)
    {
        var t = C(p.Text);
        bool light = 0.299 * t.R + 0.587 * t.G + 0.114 * t.B > 128;      // светлый текст → полупрозрачно-белые «карточки»
        var r = Application.Current.Resources;
        r["Fg"] = new SolidColorBrush(t);
        r["Card"] = new SolidColorBrush(light ? Color.FromArgb(0x28, 255, 255, 255) : Color.FromArgb(0x22, 0, 0, 0));
        r["CardHi"] = new SolidColorBrush(light ? Color.FromArgb(0x55, 255, 255, 255) : Color.FromArgb(0x44, 0, 0, 0));
    }

    public static Brush Bg(Profile p, out RotateTransform rot)
    {
        Color a = C(p.C1), b = C(p.C2); rot = null;
        if (!p.Gradient) return new SolidColorBrush(a);
        rot = new RotateTransform(p.Angle, .5, .5);
        return new LinearGradientBrush(a, b, new Point(0, .5), new Point(1, .5)) { RelativeTransform = rot };
    }

    public static Brush Glass(Profile p, byte alpha)
    {
        Color a = C(p.C1), b = C(p.C2); a.A = alpha; b.A = alpha;
        return p.Gradient ? new LinearGradientBrush(a, b, 45) : new SolidColorBrush(a);
    }

    // Градиент плавно «перетекает», пока окно показано; 20 кадров в секунду — незаметно для процессора.
    // Стартуем и останавливаемся с ТЕКУЩЕГО угла: раньше при остановке угол мгновенно возвращался к исходному,
    // и цвета острова при закрытии дёргались.
    public static void Spin(RotateTransform rot, double angle, bool on)
    {
        if (rot == null) return;
        double cur = rot.Angle;
        if (on)
        {
            var an = new DoubleAnimation(cur, cur + 360, TimeSpan.FromSeconds(16)) { RepeatBehavior = RepeatBehavior.Forever };
            Timeline.SetDesiredFrameRate(an, 20);
            rot.BeginAnimation(RotateTransform.AngleProperty, an);
        }
        else { rot.BeginAnimation(RotateTransform.AngleProperty, null); rot.Angle = cur; }
    }

    public static void FadeIn(UIElement el, int delay, int dur = 220)
    {
        el.Opacity = 0;
        var a = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(dur)) { BeginTime = TimeSpan.FromMilliseconds(delay) };
        a.Completed += (_, _) => { el.BeginAnimation(UIElement.OpacityProperty, null); el.Opacity = 1; };
        el.BeginAnimation(UIElement.OpacityProperty, a);
    }
}

// Погода через Open-Meteo: бесплатно, без ключа. Город превращается в координаты один раз.
public static class Weather
{
    static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(10) };

    public static async Task<bool> Update(Config c)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(c.City)) return false;
            if (c.CityKey != c.City)
            {
                var url = $"https://geocoding-api.open-meteo.com/v1/search?name={Uri.EscapeDataString(c.City)}&count=1&language={c.Lang}";
                using var g = JsonDocument.Parse(await Http.GetStringAsync(url));
                if (!g.RootElement.TryGetProperty("results", out var r) || r.GetArrayLength() == 0) return false;
                c.Lat = r[0].GetProperty("latitude").GetDouble(); c.Lon = r[0].GetProperty("longitude").GetDouble(); c.CityKey = c.City;
            }
            var wu = string.Create(CultureInfo.InvariantCulture,
                $"https://api.open-meteo.com/v1/forecast?latitude={c.Lat}&longitude={c.Lon}&current=temperature_2m,weather_code");
            using var w = JsonDocument.Parse(await Http.GetStringAsync(wu));
            var cur = w.RootElement.GetProperty("current");
            c.Temp = cur.GetProperty("temperature_2m").GetDouble(); c.WCode = cur.GetProperty("weather_code").GetInt32();
            c.Save(); return true;
        }
        catch { return false; }
    }

    public static string Icon(int code) => code switch
    {
        0 => "☀", 1 or 2 => "⛅", 3 => "☁", 45 or 48 => "≋",
        >= 51 and <= 67 => "☂", >= 71 and <= 77 => "❄", >= 80 and <= 82 => "☂", 85 or 86 => "❄", >= 95 => "⚡", _ => "☁",
    };
}
