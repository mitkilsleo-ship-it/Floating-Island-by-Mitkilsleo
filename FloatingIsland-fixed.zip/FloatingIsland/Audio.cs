using System.Diagnostics;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Shapes;
using NAudio.Wave;

namespace FloatingIsland;

// Спектр того, что сейчас играет в системе (WASAPI loopback). Работает только пока остров раскрыт и музыка играет.
public class SpectrumAnalyzer
{
    public const int Bands = 28;
    const int N = 1024, Mask = N - 1;
    readonly float[] ring = new float[N];
    readonly float[] bands = new float[Bands];
    readonly double[] re = new double[N], im = new double[N];
    static readonly double[] Win = Enumerable.Range(0, N).Select(i => 0.5 - 0.5 * Math.Cos(2 * Math.PI * i / (N - 1))).ToArray();
    int[] lo, hi; int pos; long last;
    WasapiLoopbackCapture cap;

    public float[] Level => bands;
    public bool Fresh => (Stopwatch.GetTimestamp() - Volatile.Read(ref last)) * 1000 / Stopwatch.Frequency < 250;

    public void Start()
    {
        if (cap != null) return;
        try { cap = new WasapiLoopbackCapture(); cap.DataAvailable += OnData; cap.StartRecording(); }
        catch { cap = null; }
    }

    public void Stop()
    {
        var c = cap; cap = null;
        if (c == null) return;
        try { c.DataAvailable -= OnData; c.StopRecording(); c.Dispose(); } catch { }
        Array.Clear(bands);
    }

    void OnData(object s, WaveInEventArgs e)
    {
        var f = ((WasapiLoopbackCapture)s).WaveFormat;
        int ch = f.Channels, step = f.BlockAlign;
        bool flt = f.BitsPerSample == 32;
        if (!flt && f.BitsPerSample != 16) return;
        for (int i = 0; i + step <= e.BytesRecorded; i += step)
        {
            float v = 0;
            for (int c = 0; c < ch; c++)
                v += flt ? BitConverter.ToSingle(e.Buffer, i + c * 4) : BitConverter.ToInt16(e.Buffer, i + c * 2) / 32768f;
            ring[pos++ & Mask] = v / ch;
        }
        long now = Stopwatch.GetTimestamp();
        if ((now - last) * 1000 / Stopwatch.Frequency < 33) return;   // не чаще ~30 раз в секунду
        Volatile.Write(ref last, now);
        Compute(f.SampleRate);
    }

    void Compute(int sr)
    {
        if (lo == null)
        {
            lo = new int[Bands]; hi = new int[Bands];
            for (int b = 0; b < Bands; b++)   // полосы по логарифмической шкале, 40 Гц … 12 кГц
            {
                double f0 = 40 * Math.Pow(300, b / (double)Bands), f1 = 40 * Math.Pow(300, (b + 1) / (double)Bands);
                lo[b] = Math.Max(1, (int)(f0 * N / sr)); hi[b] = Math.Min(N / 2, Math.Max(lo[b] + 1, (int)(f1 * N / sr)));
            }
        }
        for (int i = 0; i < N; i++) { re[i] = ring[(pos + i) & Mask] * Win[i]; im[i] = 0; }
        Fft(re, im);
        for (int b = 0; b < Bands; b++)
        {
            double m = 0;
            for (int k = lo[b]; k < hi[b]; k++) m = Math.Max(m, Math.Sqrt(re[k] * re[k] + im[k] * im[k]));
            double db = 20 * Math.Log10(m / (N / 4.0) + 1e-6) + b * 0.5;   // небольшой подъём высоких частот
            bands[b] = (float)Math.Clamp((db + 72) / 60, 0, 1);
        }
    }

    static void Fft(double[] re, double[] im)
    {
        int n = re.Length;
        for (int i = 1, j = 0; i < n; i++)
        {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) { (re[i], re[j]) = (re[j], re[i]); (im[i], im[j]) = (im[j], im[i]); }
        }
        for (int len = 2; len <= n; len <<= 1)
        {
            double ang = -2 * Math.PI / len, wr = Math.Cos(ang), wi = Math.Sin(ang);
            for (int i = 0; i < n; i += len)
            {
                double cr = 1, ci = 0;
                for (int k = 0; k < len / 2; k++)
                {
                    int a = i + k, b = i + k + len / 2;
                    double xr = re[b] * cr - im[b] * ci, xi = re[b] * ci + im[b] * cr;
                    re[b] = re[a] - xr; im[b] = im[a] - xi; re[a] += xr; im[a] += xi;
                    double t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t;
                }
            }
        }
    }
}

// Столбики диаграммы: быстро растут и плавно падают, поэтому не дёргаются.
public class Equalizer
{
    readonly ScaleTransform[] sc = new ScaleTransform[SpectrumAnalyzer.Bands];
    readonly double[] val = new double[SpectrumAnalyzer.Bands];

    public Equalizer(UniformGrid g)
    {
        for (int i = 0; i < sc.Length; i++)
        {
            sc[i] = new ScaleTransform(1, .08);
            var r = new Rectangle { RadiusX = 2, RadiusY = 2, Margin = new Thickness(1, 0, 1, 0), RenderTransformOrigin = new Point(.5, 1), RenderTransform = sc[i], Opacity = .9 };
            r.SetResourceReference(Shape.FillProperty, "Fg");
            g.Children.Add(r);
        }
    }

    public void Step(SpectrumAnalyzer a)
    {
        bool fresh = a != null && a.Fresh;
        for (int i = 0; i < sc.Length; i++)
        {
            double t = fresh ? a.Level[i] : 0;
            val[i] = t > val[i] ? val[i] + (t - val[i]) * .6 : val[i] * .86;
            sc[i].ScaleY = Math.Max(.08, val[i]);
        }
    }

    public void Reset() { for (int i = 0; i < sc.Length; i++) { val[i] = 0; sc[i].ScaleY = .08; } }
}
