using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace FloatingIsland;

// Полупрозрачный столбик с показателями у края экрана. Прозрачен для мыши и не забирает фокус у игры.
public class HudWindow : Window
{
    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
    [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr h, int i, int v);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);

    readonly Border card = new()
    {
        CornerRadius = new CornerRadius(16), Padding = new Thickness(14, 12, 14, 12), MinWidth = 112,
        BorderThickness = new Thickness(1), BorderBrush = new SolidColorBrush(Color.FromArgb(0x30, 255, 255, 255)),
    };
    readonly StackPanel[] row = new StackPanel[3];
    readonly TextBlock[] val = new TextBlock[3];
    readonly TranslateTransform slide = new();
    IntPtr h; bool right, shown;
    static TimeSpan Ms(int n) => TimeSpan.FromMilliseconds(n);

    public HudWindow(Profile p, bool right)
    {
        this.right = right;
        WindowStyle = WindowStyle.None; AllowsTransparency = true; Background = Brushes.Transparent;
        Topmost = true; ShowInTaskbar = false; ShowActivated = false; ResizeMode = ResizeMode.NoResize;
        SizeToContent = SizeToContent.WidthAndHeight;
        SetResourceReference(ForegroundProperty, "Fg");
        var col = new StackPanel(); string[] names = { "FPS", "CPU", "GPU" };
        for (int i = 0; i < 3; i++)
        {
            val[i] = new TextBlock { FontWeight = FontWeights.Bold, FontSize = 17 };
            row[i] = new StackPanel { Margin = new Thickness(0, i == 0 ? 0 : 8, 0, 0) };
            row[i].Children.Add(new TextBlock { Text = names[i], FontSize = 11, Opacity = .7 });
            row[i].Children.Add(val[i]); col.Children.Add(row[i]);
        }
        card.Child = col; card.RenderTransform = slide; Content = card;
        Skin(p);
    }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        h = new WindowInteropHelper(this).Handle;
        SetWindowLong(h, -20, GetWindowLong(h, -20) | 0x80 | 0x08000000 | 0x20);   // не в Alt+Tab, без фокуса, мышь проходит насквозь
    }

    public void Skin(Profile p) { card.Background = Look.Glass(p, 0xB4); FontFamily = new FontFamily(p.Font); }
    public void Pin() { if (h != IntPtr.Zero && shown) SetWindowPos(h, new IntPtr(-1), 0, 0, 0, 0, 0x13); }

    public void Set(string fps, string cpu, string gpu)
    {
        Fill(0, fps); Fill(1, cpu); Fill(2, gpu); Place();
    }

    void Fill(int i, string t)
    {
        row[i].Visibility = t == null ? Visibility.Collapsed : Visibility.Visible;
        if (t != null && val[i].Text != t) val[i].Text = t;
    }

    void Place()
    {
        card.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        var s = card.DesiredSize;
        Left = right ? SystemParameters.PrimaryScreenWidth - s.Width - 12 : 12;
        Top = (SystemParameters.PrimaryScreenHeight - s.Height) / 2;
    }

    public void Present(bool r)
    {
        right = r;
        if (shown) { Place(); return; }
        shown = true; Place(); Opacity = 0;
        if (!IsVisible) Show();
        BeginAnimation(OpacityProperty, new DoubleAnimation(1, Ms(250)));
        slide.BeginAnimation(TranslateTransform.XProperty,
            new DoubleAnimation(right ? 30 : -30, 0, Ms(350)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
    }

    public void Dismiss()
    {
        if (!shown) return; shown = false;
        var a = new DoubleAnimation(0, Ms(200)); a.Completed += (_, _) => { if (!shown) Hide(); };
        BeginAnimation(OpacityProperty, a);
        slide.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(right ? 30 : -30, Ms(250)));
    }
}
