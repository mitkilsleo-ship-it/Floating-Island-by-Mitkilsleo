using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using XamlAnimatedGif;

namespace FloatingIsland;

public partial class MainWindow : Window
{
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
    [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr h, int i, int v);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
    [DllImport("user32.dll")] static extern IntPtr SetWinEventHook(uint min, uint max, IntPtr mod, WinEventProc cb, uint pid, uint tid, uint flags);
    [DllImport("user32.dll")] static extern bool UnhookWinEvent(IntPtr h);
    [DllImport("user32.dll")] static extern bool ChangeWindowMessageFilterEx(IntPtr h, uint msg, uint action, IntPtr p);
    [DllImport("shell32.dll")] static extern void DragAcceptFiles(IntPtr h, bool on);
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)] static extern uint DragQueryFile(IntPtr d, uint i, System.Text.StringBuilder b, int n);
    [DllImport("shell32.dll")] static extern void DragFinish(IntPtr d);
    delegate void WinEventProc(IntPtr hook, uint ev, IntPtr wnd, int obj, int child, uint thread, uint time);
    [StructLayout(LayoutKind.Sequential)] struct RECT { public int L, T, R, B; }

    const int EXSTYLE = -20, TOOLWINDOW = 0x80, NOACTIVATE = 0x08000000;
    static readonly HashSet<string> Skip = new(StringComparer.OrdinalIgnoreCase)
        { "explorer", "chrome", "msedge", "firefox", "vlc", "vivaldi", "opera", "brave", "ApplicationFrameHost", "SearchHost" };

    readonly Config cfg = Config.Load();
    readonly DispatcherTimer timer = new();                                                     // 0,5–1 с, пока что-то показываем; иначе редко
    readonly DispatcherTimer pin = new() { Interval = TimeSpan.FromMilliseconds(250) };         // в игре возвращаем остров наверх
    readonly DispatcherTimer recheck = new() { Interval = TimeSpan.FromMilliseconds(1500) };    // игра разворачивается не сразу
    readonly DispatcherTimer leave = new() { Interval = TimeSpan.FromSeconds(2.5) };            // в игре сам закрывается, когда мышь ушла
    readonly DispatcherTimer weatherTimer = new() { Interval = TimeSpan.FromMinutes(30) };
    readonly DispatcherTimer vizTimer = new() { Interval = TimeSpan.FromMilliseconds(40) };     // 25 кадров/с, только пока играет музыка
    readonly MediaWatcher media = new();
    readonly Equalizer eq;
    IntPtr hwnd, hook; WinEventProc winProc;
    System.Windows.Forms.NotifyIcon tray;
    SettingsWindow settings; HudWindow hud; SpectrumAnalyzer spec;
    Stats stats; Fps fps; RotateTransform rot;
    bool open, game, busy, hidden, hudShown;
    uint gamePid; int tickN;
    string loadedGif = "";
    const double OpenW = 440, OpenH = 390;   // размер развёрнутого острова
    int gen;                                 // номер текущего раскрытия/сворачивания: устаревшие колбэки анимаций ничего не ломают
    volatile bool vizOn;                     // нужна ли сейчас диаграмма
    readonly object vizGate = new();

    public event Action Applied;
    public Config Cfg => cfg;
    Profile P => cfg.Profiles[cfg.Active];
    string Tr(string k) => Loc.T(cfg.Lang, k);
    static TimeSpan Ms(int n) => TimeSpan.FromMilliseconds(n);
    static string V(float v, string u) => float.IsNaN(v) ? "--" : $"{v:0}{u}";
    static string Pair(string a, string b) => a == null ? b : b == null ? a : a + "  " + b;
    bool HasWeather => cfg.Temp.HasValue && !string.IsNullOrWhiteSpace(cfg.City);
    double CollapsedW => HasWeather ? 190 : 150;
    bool AnyMetric => cfg.HudFps || cfg.HudCpuLoad || cfg.HudCpuTemp || cfg.HudGpuLoad || cfg.HudGpuTemp;

    public MainWindow()
    {
        InitializeComponent();
        Full.Width = OpenW - 34; Full.Height = OpenH - 28;   // рамка 2 px + боковые отступы 32 px; сверху 14 px, снизу 12 px
        try { Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.BelowNormal; } catch { }   // игре — приоритет
        SetResourceReference(ForegroundProperty, "Fg");
        eq = new Equalizer(VizGrid);
        Isl.SizeChanged += (_, _) => FixCorner();
        Deactivated += (_, _) => { if (open && !busy && !game) SetOpen(false); };
        Isl.MouseEnter += (_, _) => leave.Stop();
        Isl.MouseLeave += (_, _) => { if (open && game) leave.Start(); };
        leave.Tick += (_, _) => { leave.Stop(); if (game) SetOpen(false); };
        timer.Tick += Tick;
        pin.Tick += (_, _) => Pin();
        recheck.Tick += (_, _) => { recheck.Stop(); Refresh(); };
        weatherTimer.Tick += (_, _) => RefreshWeather();
        vizTimer.Tick += (_, _) => eq.Step(spec);
        media.Changed += () => Dispatcher.BeginInvoke(new Action(UpdateMedia));
        Apply(); BuildApps(); MakeTray(); FitWindow(); Tick(null, null); timer.Start();
        media.Start(); RefreshWeather(); weatherTimer.Start();
    }

    // ---------- поверх игр ----------
    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        hwnd = new WindowInteropHelper(this).Handle;
        SetWindowLong(hwnd, EXSTYLE, GetWindowLong(hwnd, EXSTYLE) | TOOLWINDOW);        // не показывать в Alt+Tab
        HwndSource.FromHwnd(hwnd).AddHook(WndProc);
        // Окно с правами администратора не принимает перетаскивание из Проводника — разрешаем классический WM_DROPFILES.
        foreach (uint wm in new uint[] { 0x233, 0x49, 0x4A }) ChangeWindowMessageFilterEx(hwnd, wm, 1, IntPtr.Zero);
        DragAcceptFiles(hwnd, true);
        RegisterHotKey(hwnd, 1, 0x3, 0x49);   // Ctrl+Alt+I — открыть/закрыть
        RegisterHotKey(hwnd, 2, 0x3, 0x48);   // Ctrl+Alt+H — показать/скрыть
        winProc = (_, _, _, _, _, _, _) => Dispatcher.BeginInvoke(new Action(() => { Refresh(); recheck.Stop(); recheck.Start(); }));
        hook = SetWinEventHook(3, 3, IntPtr.Zero, winProc, 0, 0, 2);                      // смена активного окна, без опроса
        game = false; Refresh();                                                           // окно уже создано: заново определяем игру
    }

    IntPtr WndProc(IntPtr h, int msg, IntPtr wp, IntPtr lp, ref bool handled)
    {
        if (msg == 0x233)   // WM_DROPFILES
        {
            var sb = new System.Text.StringBuilder(520); uint n = DragQueryFile(wp, 0xFFFFFFFF, null, 0);
            for (uint i = 0; i < n; i++) { DragQueryFile(wp, i, sb, sb.Capacity); HandleFile(sb.ToString()); }
            DragFinish(wp); cfg.Save(); Apply(); BuildApps(); handled = true;
        }
        else if (msg == 0x0312)   // WM_HOTKEY
        {
            if (wp.ToInt32() == 1) SetOpen(!open); else { hidden = !hidden; UpdateVisibility(); }
            handled = true;
        }
        return IntPtr.Zero;
    }

    protected override void OnClosed(EventArgs e)
    {
        UnhookWinEvent(hook); UnregisterHotKey(hwnd, 1); UnregisterHotKey(hwnd, 2);
        spec?.Stop(); fps?.Stop(); stats?.Close();   // отпускаем ETW-сессию и драйвер датчиков, иначе они остаются в системе
        if (tray != null) { tray.Visible = false; tray.Dispose(); }
        base.OnClosed(e);
    }

    void Pin() { SetWindowPos(hwnd, new IntPtr(-1), 0, 0, 0, 0, 0x13); hud?.Pin(); }   // HWND_TOPMOST, без смены фокуса

    void Refresh()
    {
        bool g = IsGame(out gamePid);
        if (g != game) { game = g; SetHud(g); }
        Pin();
    }

    // В игре окно не забирает фокус (NOACTIVATE): островок можно открыть и нажимать, а игра остаётся активной.
    void SetHud(bool on)
    {
        int ex = GetWindowLong(hwnd, EXSTYLE);
        SetWindowLong(hwnd, EXSTYLE, on ? ex | NOACTIVATE : ex & ~NOACTIVATE);
        if (open) SetOpen(false); else Resize();
        UpdateVisibility();
        if (on) pin.Start(); else pin.Stop();
    }

    void UpdateVisibility() { Isl.Visibility = hidden ? Visibility.Hidden : Visibility.Visible; UpdateHud(); }
    public void HudSettingChanged() { UpdateHud(); Tick(null, null); }

    // Столбик показателей: в играх (или всегда — по настройке), с выбранной стороны экрана.
    void UpdateHud()
    {
        bool want = !hidden && cfg.Hud && AnyMetric && (game || cfg.HudAlways);
        bool right = cfg.HudSide == "right";
        if (want) { hud ??= new HudWindow(P, right); hud.Present(right); } else hud?.Dismiss();
        hudShown = want;
    }

    // Окно ровно по размеру острова: Windows компонует минимум пикселей, особенно поверх игры.
    // Положение и размер меняем ОДНИМ вызовом: раньше Left применялся сразу, а Width/Height — на следующей раскладке,
    // и между ними окно на кадр (а при нагрузке — на заметное время) «подпрыгивало» в сторону.
    void FitWindow()
    {
        double w = open ? OpenW + 40 : 340, h = open ? OpenH + 40 : 48;
        double left = (SystemParameters.PrimaryScreenWidth - w) / 2;
        if (hwnd == IntPtr.Zero) { Width = w; Height = h; Left = left; Top = 0; return; }   // окна ещё нет — обычные свойства
        var d = VisualTreeHelper.GetDpi(this);
        SetWindowPos(hwnd, IntPtr.Zero, (int)Math.Round(left * d.DpiScaleX), 0,
            (int)Math.Round(w * d.DpiScaleX), (int)Math.Round(h * d.DpiScaleY), 0x14);   // SWP_NOZORDER | SWP_NOACTIVATE
    }

    void FixCorner()
    {
        double r = Math.Min(P.Corner, Isl.ActualHeight / 2);
        if (Math.Abs(Isl.CornerRadius.TopLeft - r) > .01) Isl.CornerRadius = new CornerRadius(r);   // не дёргаем раскладку на каждом кадре анимации
    }

    bool IsGame(out uint pid)
    {
        pid = 0; var h = GetForegroundWindow();
        if (h == IntPtr.Zero || h == hwnd) return false;
        GetWindowThreadProcessId(h, out pid);
        if (pid == Environment.ProcessId || !GetWindowRect(h, out var r)) return false;
        var b = System.Windows.Forms.Screen.FromHandle(h).Bounds;
        if (r.L > b.Left || r.T > b.Top || r.R < b.Right || r.B < b.Bottom) return false;
        try { return !Skip.Contains(Process.GetProcessById((int)pid).ProcessName); } catch { return false; }
    }

    // ---------- тик ----------
    void Tick(object s, EventArgs e)
    {
        Refresh();
        var now = DateTime.Now;
        var ci = CultureInfo.GetCultureInfo(cfg.Lang == "ru" ? "ru-RU" : "en-US");
        tickN++;
        bool fast = hudShown && cfg.HudFps;                                                    // FPS обновляем чаще — тогда он плавный
        bool hudStats = hudShown && (cfg.HudCpuLoad || cfg.HudCpuTemp || cfg.HudGpuLoad || cfg.HudGpuTemp);
        if ((open || hudStats) && (!fast || tickN % 2 == 0 || stats == null))                  // датчики — раз в секунду, но в фоне:
        {                                                                                      // на UI-потоке опрос занимал десятки мс (первый — сотни) и рвал анимацию
            stats ??= new Stats();
            stats.UpdateAsync(() => Dispatcher.BeginInvoke(new Action(ShowStats)));
        }
        if (open) ShowStats();
        if (hudShown)
        {
            string f = null;
            if (cfg.HudFps)
            {
                if (game) { if (fps == null) { fps = new Fps(); fps.Start(); } fps.Pid = gamePid; f = fps.Read().ToString(); }
                else f = "--";
            }
            string c = hudStats ? Pair(cfg.HudCpuLoad ? V(stats.CpuLoad, "%") : null, cfg.HudCpuTemp ? V(stats.CpuTemp, "°") : null) : null;
            string g = hudStats ? Pair(cfg.HudGpuLoad ? V(stats.GpuLoad, "%") : null, cfg.HudGpuTemp ? V(stats.GpuTemp, "°") : null) : null;
            hud.Set(f, c, g);
        }
        Pill.Text = now.ToString("HH:mm", ci) + (HasWeather ? $"  {Weather.Icon(cfg.WCode)} {cfg.Temp:0}°" : "");
        if (open) { BigTime.Text = now.ToString("HH:mm:ss", ci); DateTxt.Text = now.ToString("dddd, d MMMM yyyy", ci); }
        // Без дела просыпаемся только к смене минуты (но не реже раза в 3 с — чтобы заметить игру).
        // Пока остров раскрыт, подстраиваемся под границу секунды: с фиксированным интервалом в 1 с тик «уплывал»,
        // и время от времени секунды на больших часах перескакивали через цифру.
        int toSec = 1000 - DateTime.Now.Millisecond + 8;
        timer.Interval = fast ? Ms(open ? Math.Min(500, toSec) : 500) : open ? Ms(toSec) : hudShown ? TimeSpan.FromSeconds(1)
            : Ms((int)Math.Min(3000, 60000 - (now.Second * 1000 + now.Millisecond)) + 30);
    }

    void ShowStats()
    {
        if (!open || stats == null) return;
        StatTxt.Text = $"CPU {V(stats.CpuLoad, "%")} {V(stats.CpuTemp, "°")}  GPU {V(stats.GpuLoad, "%")} {V(stats.GpuTemp, "°")}";
    }

    // ---------- погода ----------
    public async void RefreshWeather()
    {
        if (await Weather.Update(cfg)) UpdateWeatherUi();
        else if (string.IsNullOrWhiteSpace(cfg.City)) { cfg.Temp = null; UpdateWeatherUi(); }
    }

    void UpdateWeatherUi()
    {
        WeatherTxt.Text = HasWeather ? $"{Weather.Icon(cfg.WCode)} {cfg.Temp:0}°C · {cfg.City}" : "";
        WeatherTxt.Visibility = HasWeather ? Visibility.Visible : Visibility.Collapsed;
        if (!open) Resize();
        Tick(null, null);
    }

    // ---------- музыка и диаграмма ----------
    async void UpdateMedia()
    {
        if (!open) return;   // пока свёрнут — ничего не делаем; обновимся при раскрытии
        var i = await media.GetAsync();
        if (!open) return;   // пока ждали ответ системы, остров успели свернуть
        if (i == null || string.IsNullOrEmpty(i.Title)) { ShowMedia(false); SetViz(false); return; }
        MTitle.Text = i.Title; MArtist.Text = i.Artist; MPlay.Content = i.Playing ? "⏸" : "▶";
        Art.Source = i.Art; ArtBox.Visibility = i.Art == null ? Visibility.Collapsed : Visibility.Visible;
        ShowMedia(true);
        SetViz(i.Playing);
    }

    // Плеер появляется плавно «выезжающим» блоком, а не выпрыгивает посреди анимации и не сдвигает плитки рывком.
    void ShowMedia(bool on)
    {
        if (on == (MediaBox.Visibility == Visibility.Visible)) return;
        if (!on) { MediaBox.Visibility = Visibility.Collapsed; return; }
        var sy = new ScaleTransform(1, .02);
        MediaBox.LayoutTransform = sy; MediaBox.Visibility = Visibility.Visible;
        var a = new DoubleAnimation(1, Ms(280)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
        a.Completed += (_, _) => { sy.BeginAnimation(ScaleTransform.ScaleYProperty, null); sy.ScaleY = 1; MediaBox.LayoutTransform = Transform.Identity; };
        sy.BeginAnimation(ScaleTransform.ScaleYProperty, a);
        Look.FadeIn(MediaBox, 0, 280);
    }

    // Открытие и закрытие аудиоустройства (WASAPI) блокирует поток на десятки миллисекунд — делаем это в фоне.
    void SetViz(bool on)
    {
        vizOn = on;
        if (on) { spec ??= new SpectrumAnalyzer(); vizTimer.Start(); VizGrid.Visibility = Visibility.Visible; }
        else { vizTimer.Stop(); eq.Reset(); VizGrid.Visibility = Visibility.Hidden; }
        if (spec != null) Task.Run(SyncViz);
    }

    // Каждый запуск приводит захват к актуальному vizOn; lock не даёт запускам перегнать друг друга.
    void SyncViz()
    {
        lock (vizGate) { var s = spec; if (s == null) return; if (vizOn) s.Start(); else s.Stop(); }
    }

    void MPrev(object s, RoutedEventArgs e) => media.Prev();
    void MNext(object s, RoutedEventArgs e) => media.Next();
    void MPlayClick(object s, RoutedEventArgs e) => media.Toggle();

    // ---------- анимации ----------
    void Resize()
    {
        double w = open ? OpenW : CollapsedW, h = open ? OpenH : 36;
        IEasingFunction ez = open ? new BackEase { Amplitude = .25, EasingMode = EasingMode.EaseOut }
                                  : new CubicEase { EasingMode = EasingMode.EaseOut };
        var ah = new DoubleAnimation(h, Ms(420)) { EasingFunction = ez };
        if (!open) { int my = gen; ah.Completed += (_, _) => { if (!open && my == gen) FinishClose(); }; }   // остров дошёл до «таблетки»
        Isl.BeginAnimation(FrameworkElement.WidthProperty, new DoubleAnimation(w, Ms(420)) { EasingFunction = ez });
        Isl.BeginAnimation(FrameworkElement.HeightProperty, ah);
    }

    // Окно сжимаем и градиент останавливаем только когда остров уже свернулся. Раньше окно сжималось через 140 мс,
    // когда остров был ещё высотой в сотню пикселей, — его обрезало по краю, это и было видно как рывок при закрытии.
    void FinishClose()
    {
        Look.Spin(rot, P.Angle, false);
        FitWindow(); Tick(null, null);
    }

    void SetOpen(bool v)
    {
        if (open == v) return;
        open = v; int my = ++gen;
        if (v)
        {
            // Всё тяжёлое — ДО анимации: окно сразу нужного размера, тексты заполнены, содержимое разложено.
            // Часы анимации идут по реальному времени, поэтому любая задержка внутри неё выглядела бы как скачок.
            FitWindow();
            Full.Visibility = Visibility.Visible;
            Tick(null, null);
            if (!open || my != gen) return;
            Full.UpdateLayout();
            // Сама анимация стартует отдельным шагом — после того, как окно и разметка отрисованы.
            Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() => { if (open && my == gen) BeginOpen(); }));
        }
        else
        {
            leave.Stop(); CloseFolder(true); SetViz(false);
            AnimationBehavior.GetAnimator(Gif)?.Pause();   // гифка на паузе, пока остров свёрнут
            Resize();
            var a = new DoubleAnimation(0, Ms(140));
            a.Completed += (_, _) => { if (!open && my == gen) Full.Visibility = Visibility.Collapsed; };
            Full.BeginAnimation(OpacityProperty, a);
            ShowPill();
        }
    }

    void BeginOpen()
    {
        Resize(); Look.Spin(rot, P.Angle, P.Animate);
        HidePill();
        Full.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, Ms(260)) { BeginTime = Ms(140) });
        AnimationBehavior.GetAnimator(Gif)?.Play();
        AnimateTiles(160); UpdateMedia();
    }

    // Надпись-«таблетка» плавно гаснет при раскрытии и плавно появляется при сворачивании (раньше пропадала мгновенно).
    void HidePill()
    {
        int my = gen;
        var a = new DoubleAnimation(0, Ms(110));
        a.Completed += (_, _) => { if (open && my == gen) PillBox.Visibility = Visibility.Collapsed; };
        PillBox.BeginAnimation(OpacityProperty, a);
    }

    void ShowPill()
    {
        PillBox.Visibility = Visibility.Visible;
        PillBox.BeginAnimation(OpacityProperty, null); PillBox.Opacity = 0;   // базовое значение 0: пока ждём задержку, надпись не мигает
        PillBox.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, Ms(200)) { BeginTime = Ms(180) });
    }

    void AnimateTiles(int baseDelay)
    {
        int i = 0;
        foreach (UIElement t in AppsPanel.Children) Look.FadeIn(t, baseDelay + 25 * i++);
    }

    void Expand(object s, MouseButtonEventArgs e) => SetOpen(true);
    void Collapse(object s, RoutedEventArgs e) => SetOpen(false);
    void ToSettings(object s, RoutedEventArgs e) => OpenSettings();

    public void OpenSettings()
    {
        if (settings is { IsLoaded: true }) { settings.Activate(); return; }
        settings = new SettingsWindow(this); settings.Show();
    }

    // ---------- оформление ----------
    public void Apply()
    {
        var p = P; Look.Theme(p);
        Isl.Background = Look.Bg(p, out rot); Look.Spin(rot, p.Angle, open && p.Animate);
        FontFamily = new FontFamily(p.Font); FontSize = p.Size;
        FixCorner();
        hud?.Skin(p);
        var gif = Config.ResolveGif(p.Gif);
        if (gif != loadedGif)
        {
            loadedGif = gif;
            AnimationBehavior.SetSourceUri(Gif, File.Exists(gif) ? new Uri(gif) : null);
        }
        UpdateWeatherUi();
        Applied?.Invoke();
    }

    public void Relocalize() { BuildApps(); Tick(null, null); }

    // ---------- иконки и быстрые приложения ----------
    static string Resolve(string p)
    {
        if (p.StartsWith("ms-settings:"))
            p = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "ImmersiveControlPanel", "SystemSettings.exe");
        if (File.Exists(p)) return p;
        foreach (var d in new[] { Environment.SystemDirectory, Environment.GetFolderPath(Environment.SpecialFolder.Windows) })
        { var f = System.IO.Path.Combine(d, p); if (File.Exists(f)) return f; }
        return null;
    }

    static ImageSource IconOf(string path)
    {
        try
        {
            var f = Resolve(path); if (f == null) return null;
            using var ic = System.Drawing.Icon.ExtractAssociatedIcon(f);
            return ic == null ? null : Imaging.CreateBitmapSourceFromHIcon(ic.Handle, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
        }
        catch { return null; }
    }

    void BuildApps()
    {
        AppsPanel.Children.Clear();
        foreach (var a in cfg.Apps.ToList()) AppsPanel.Children.Add(MakeTile(a, cfg.Apps, false));
        var add = new Button { Content = new TextBlock { Text = "+", FontSize = 22, Width = 30, TextAlignment = TextAlignment.Center }, VerticalAlignment = VerticalAlignment.Top };
        add.Click += (_, _) =>
        {
            busy = true; var d = new Microsoft.Win32.OpenFileDialog { Filter = "Apps|*.exe;*.lnk|All|*.*" };
            bool ok = d.ShowDialog() == true; busy = false;
            if (!ok) return;
            AddApp(d.FileName); cfg.Save(); BuildApps();
        };
        AppsPanel.Children.Add(add);
        if (open) AnimateTiles(0);
    }

    void AddApp(string path) => cfg.Apps.Add(new AppItem { Name = System.IO.Path.GetFileNameWithoutExtension(path), Path = path });

    void HandleFile(string f)
    {
        var ext = System.IO.Path.GetExtension(f).ToLowerInvariant();
        try { if (ext == ".gif") P.Gif = Config.ImportGif(f); else if (ext is ".exe" or ".lnk") AddApp(f); } catch { }
    }

    // ---------- иконка в трее ----------
    void MakeTray()
    {
        using var bmp = new System.Drawing.Bitmap(32, 32);
        using (var g = System.Drawing.Graphics.FromImage(bmp))
        {
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.FillEllipse(System.Drawing.Brushes.MediumPurple, 1, 9, 30, 14);
        }
        var menu = new System.Windows.Forms.ContextMenuStrip();
        menu.Opening += (_, _) =>
        {
            menu.Items.Clear();
            menu.Items.Add(Tr("openclose"), null, (_, _) => SetOpen(!open));
            menu.Items.Add(Tr("showhide"), null, (_, _) => { hidden = !hidden; UpdateVisibility(); });
            menu.Items.Add(Tr("settings"), null, (_, _) => OpenSettings());
            menu.Items.Add(Tr("exit"), null, (_, _) => Application.Current.Shutdown());
        };
        tray = new System.Windows.Forms.NotifyIcon { Icon = System.Drawing.Icon.FromHandle(bmp.GetHicon()), Text = "Floating Island", ContextMenuStrip = menu, Visible = true };
        tray.MouseClick += (_, e) => { if (e.Button == System.Windows.Forms.MouseButtons.Left) OpenSettings(); };
    }
}
