# Необязательно: запуск запустить от имени администратора. Ставит остров в «высокий» слой окон Windows
# (как экранная клавиатура) — на случай, если обычный режим всё же прячется за игрой.
#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'
$pub = Join-Path $PSScriptRoot 'out-ui'
dotnet publish "$PSScriptRoot\FloatingIsland.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:UiAccess=true -o $pub
if ($LASTEXITCODE -ne 0) { throw 'Сборка не удалась' }
$cert = Get-ChildItem Cert:\LocalMachine\My | Where-Object Subject -eq 'CN=FloatingIsland' | Select-Object -First 1
if (-not $cert) { $cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject 'CN=FloatingIsland' -CertStoreLocation Cert:\LocalMachine\My -NotAfter (Get-Date).AddYears(10) }
$public = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(,$cert.RawData)
foreach ($name in 'Root', 'TrustedPublisher') {
    $st = New-Object System.Security.Cryptography.X509Certificates.X509Store($name, 'LocalMachine'); $st.Open('ReadWrite'); $st.Add($public); $st.Close()
}
Set-AuthenticodeSignature -FilePath "$pub\FloatingIsland.exe" -Certificate $cert -HashAlgorithm SHA256 | Out-Null
Get-Process FloatingIsland -ErrorAction SilentlyContinue | Stop-Process -Force
$dst = "$env:ProgramFiles\FloatingIsland"   # uiAccess разрешён только из защищённых папок
New-Item -ItemType Directory -Force $dst | Out-Null
Copy-Item "$pub\FloatingIsland.exe" $dst -Force
Start-Process "$dst\FloatingIsland.exe"
