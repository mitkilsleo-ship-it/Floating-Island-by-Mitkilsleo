using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Windows.Media.Control;
using WF = Windows.Foundation;

namespace FloatingIsland;

public class MediaInfo { public string Title, Artist; public bool Playing; public ImageSource Art; }

// Управление музыкой через системный медиа-центр Windows (Spotify, браузер, плееры...). Без опроса — только события.
public class MediaWatcher
{
    GlobalSystemMediaTransportControlsSessionManager mgr;
    GlobalSystemMediaTransportControlsSession ses;
    readonly WF.TypedEventHandler<GlobalSystemMediaTransportControlsSession, MediaPropertiesChangedEventArgs> onProps;
    readonly WF.TypedEventHandler<GlobalSystemMediaTransportControlsSession, PlaybackInfoChangedEventArgs> onPlay;
    string artKey = ""; ImageSource art;
    public event Action Changed;

    public MediaWatcher()
    {
        onProps = (_, _) => Changed?.Invoke();
        onPlay = (_, _) => Changed?.Invoke();
    }

    public async void Start()
    {
        try
        {
            mgr = await GlobalSystemMediaTransportControlsSessionManager.RequestAsync();
            mgr.CurrentSessionChanged += (_, _) => Hook();
            Hook();
        }
        catch { }
    }

    void Hook()
    {
        if (ses != null) { ses.MediaPropertiesChanged -= onProps; ses.PlaybackInfoChanged -= onPlay; }
        ses = mgr.GetCurrentSession();
        if (ses != null) { ses.MediaPropertiesChanged += onProps; ses.PlaybackInfoChanged += onPlay; }
        Changed?.Invoke();
    }

    public async Task<MediaInfo> GetAsync()
    {
        var s = ses; if (s == null) return null;
        try
        {
            var p = await s.TryGetMediaPropertiesAsync();
            var info = new MediaInfo
            {
                Title = p.Title, Artist = p.Artist,
                Playing = s.GetPlaybackInfo().PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing,
            };
            var key = p.Title + "|" + p.Artist;
            if (key != artKey)   // обложку декодируем только при смене трека, а не при паузе/старте
            {
                artKey = key; art = null;
                if (p.Thumbnail != null)
                {
                    using var st = await p.Thumbnail.OpenReadAsync();
                    var bi = new BitmapImage();
                    bi.BeginInit(); bi.CacheOption = BitmapCacheOption.OnLoad; bi.DecodePixelWidth = 96;   // показывается 38×38 — полноразмерную обложку декодировать незачем
                    bi.StreamSource = st.AsStreamForRead(); bi.EndInit();
                    bi.Freeze(); art = bi;
                }
            }
            info.Art = art; return info;
        }
        catch { return null; }
    }

    public void Prev() { try { _ = ses?.TrySkipPreviousAsync(); } catch { } }
    public void Next() { try { _ = ses?.TrySkipNextAsync(); } catch { } }
    public void Toggle() { try { _ = ses?.TryTogglePlayPauseAsync(); } catch { } }
}
