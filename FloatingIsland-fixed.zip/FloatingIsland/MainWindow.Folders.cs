using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace FloatingIsland;

// Папки приложений и перетаскивание плиток — как значки на телефоне.
public partial class MainWindow
{
    AppItem openFolder;
    Point nearC;

    Button MakeTile(AppItem a, List<AppItem> owner, bool inFolder)
    {
        var sp = new StackPanel { Width = 72 };
        if (a.Items != null)   // папка: мини-сетка 3×3 из иконок внутри
        {
            var g = new UniformGrid { Rows = 3, Columns = 3 };
            foreach (var c in a.Items.Take(9))
            {
                var ic = IconOf(c.Path);
                g.Children.Add(ic != null ? new Image { Source = ic, Margin = new Thickness(1) } : new Border());
            }
            var box = new Border { Width = 42, Height = 42, CornerRadius = new CornerRadius(11), Padding = new Thickness(4), Child = g, Margin = new Thickness(0, 0, 0, 3) };
            box.SetResourceReference(Border.BackgroundProperty, "CardHi");
            sp.Children.Add(box);
        }
        else
        {
            var icon = IconOf(a.Path);
            sp.Children.Add(icon != null
                ? new Image { Source = icon, Width = 28, Height = 28, Margin = new Thickness(0, 0, 0, 3) }
                : new TextBlock { Text = a.Name[..1].ToUpper(), FontSize = 22, HorizontalAlignment = HorizontalAlignment.Center });
        }
        sp.Children.Add(new TextBlock { Text = a.Name, FontSize = 11, TextAlignment = TextAlignment.Center, TextTrimming = TextTrimming.CharacterEllipsis });

        var b = new Button { Content = sp, ToolTip = a.Name, Tag = a };
        b.Click += (_, _) =>
        {
            if (a.Items != null) OpenFolder(a);
            else { try { Process.Start(new ProcessStartInfo(a.Path) { UseShellExecute = true }); } catch { } }
        };

        var cm = new ContextMenu();
        void Item(string head, Action act) { var mi = new MenuItem { Header = head }; mi.Click += (_, _) => act(); cm.Items.Add(mi); }
        if (a.Items != null)
        {
            Item(Tr("rename"), () => { OpenFolder(a); FolderName.Focus(); FolderName.SelectAll(); });
            Item(Tr("dissolve"), () => { int i = cfg.Apps.IndexOf(a); cfg.Apps.RemoveAt(i); cfg.Apps.InsertRange(i, a.Items); Commit(); });
            Item(Tr("del"), () => { cfg.Apps.Remove(a); Commit(); });
        }
        else
        {
            if (inFolder) Item(Tr("moveout"), () => { owner.Remove(a); cfg.Apps.Insert(cfg.Apps.IndexOf(openFolder) + 1, a); Commit(); });
            Item(Tr("del"), () => { owner.Remove(a); Commit(); });
        }
        b.ContextMenu = cm;
        if (!inFolder) AttachDrag(b, a);
        return b;
    }

    // Зажал и потянул — плитка «подхватывается»; над центром другой плитки она затемняется (будет папка), у края — просто смена места.
    void AttachDrag(Button b, AppItem a)
    {
        Point start = default; bool down = false, drag = false; Button hint = null;
        var sc = new ScaleTransform(1, 1); var tt = new TranslateTransform();
        b.RenderTransformOrigin = new Point(.5, .5);
        b.RenderTransform = new TransformGroup { Children = { sc, tt } };
        b.PreviewMouseLeftButtonDown += (_, e) => { start = e.GetPosition(AppsPanel); down = true; drag = false; };
        b.PreviewMouseMove += (_, e) =>
        {
            if (!down || e.LeftButton != MouseButtonState.Pressed) return;
            var p = e.GetPosition(AppsPanel);
            if (!drag && (Math.Abs(p.X - start.X) > 8 || Math.Abs(p.Y - start.Y) > 8))
            {
                drag = true; Panel.SetZIndex(b, 10); b.Opacity = .85;
                var up = new DoubleAnimation(1.15, Ms(120));
                sc.BeginAnimation(ScaleTransform.ScaleXProperty, up); sc.BeginAnimation(ScaleTransform.ScaleYProperty, up);
            }
            if (!drag) return;
            tt.X = p.X - start.X; tt.Y = p.Y - start.Y;
            var t = Nearest(a, p, out bool merge);
            var want = merge ? t : null;
            if (want != hint) { if (hint != null) hint.Opacity = 1; hint = want; if (hint != null) hint.Opacity = .5; }
        };
        b.PreviewMouseLeftButtonUp += (_, e) =>
        {
            if (!down) return; down = false;
            if (!drag) return;
            e.Handled = true; b.ReleaseMouseCapture();   // это было перетаскивание, а не клик
            if (hint != null) hint.Opacity = 1;
            Drop(a, e.GetPosition(AppsPanel));
        };
    }

    Button Nearest(AppItem a, Point p, out bool merge)
    {
        Button best = null; double bd = double.MaxValue; Point bc = default;
        foreach (var t in AppsPanel.Children.OfType<Button>())
        {
            if (t.Tag is not AppItem || ReferenceEquals(t.Tag, a)) continue;
            var c = t.TranslatePoint(new Point(t.ActualWidth / 2, t.ActualHeight / 2), AppsPanel);
            double d = (c.X - p.X) * (c.X - p.X) + (c.Y - p.Y) * (c.Y - p.Y);
            if (d < bd) { bd = d; best = t; bc = c; }
        }
        nearC = bc;
        merge = best != null && a.Items == null
                && Math.Abs(p.X - bc.X) < best.ActualWidth * .3 && Math.Abs(p.Y - bc.Y) < best.ActualHeight * .3;
        return best;
    }

    void Drop(AppItem a, Point p)
    {
        var t = Nearest(a, p, out bool merge);
        if (t != null)
        {
            var target = (AppItem)t.Tag;
            cfg.Apps.Remove(a);
            if (merge)
            {
                if (target.Items != null) target.Items.Add(a);
                else cfg.Apps[cfg.Apps.IndexOf(target)] = new AppItem { Name = Tr("foldername"), Items = new() { target, a } };
            }
            else { int ti = cfg.Apps.IndexOf(target); cfg.Apps.Insert(nearC.X < p.X ? ti + 1 : ti, a); }
        }
        Commit();
    }

    // Папка из одного приложения распадается, пустая исчезает — как на телефоне.
    void Commit()
    {
        for (int i = cfg.Apps.Count - 1; i >= 0; i--)
        {
            var f = cfg.Apps[i];
            if (f.Items == null) continue;
            if (f.Items.Count == 0) cfg.Apps.RemoveAt(i); else if (f.Items.Count == 1) cfg.Apps[i] = f.Items[0];
        }
        cfg.Save(); BuildApps();
        if (openFolder != null) { if (cfg.Apps.Contains(openFolder)) BuildFolder(); else CloseFolder(true); }
    }

    // ---------- открытая папка ----------
    void OpenFolder(AppItem f)
    {
        openFolder = f; FolderName.Text = f.Name; BuildFolder();
        AppsScroll.Visibility = Visibility.Collapsed; FolderView.Visibility = Visibility.Visible;
        var sc = new ScaleTransform(.9, .9); FolderView.RenderTransformOrigin = new Point(.5, 0); FolderView.RenderTransform = sc;
        var d = new DoubleAnimation(1, Ms(300)) { EasingFunction = new BackEase { Amplitude = .25, EasingMode = EasingMode.EaseOut } };
        sc.BeginAnimation(ScaleTransform.ScaleXProperty, d); sc.BeginAnimation(ScaleTransform.ScaleYProperty, d);
        Look.FadeIn(FolderView, 0, 200);
    }

    void CloseFolder(bool instant)
    {
        if (openFolder == null) return;
        openFolder = null;
        FolderView.Visibility = Visibility.Collapsed; AppsScroll.Visibility = Visibility.Visible;
        if (!instant) Look.FadeIn(AppsScroll, 0, 200);
    }

    void BuildFolder()
    {
        FolderPanel.Children.Clear();
        if (openFolder == null) return;
        foreach (var c in openFolder.Items.ToList()) FolderPanel.Children.Add(MakeTile(c, openFolder.Items, true));
    }

    void FolderBack(object s, RoutedEventArgs e) { Keyboard.ClearFocus(); CloseFolder(false); BuildApps(); }
    void FolderKey(object s, KeyEventArgs e) { if (e.Key == Key.Enter) Keyboard.ClearFocus(); }
    void FolderRename(object s, RoutedEventArgs e)
    {
        var t = FolderName.Text.Trim();
        if (openFolder != null && t.Length > 0 && t != openFolder.Name) { openFolder.Name = t; cfg.Save(); }
    }
}
