using System.Globalization;
using System.IO;
using System.Text.Json;
using System.Windows;
using LibreHardwareMonitor.Hardware;
using Microsoft.Diagnostics.Tracing.Session;

namespace FloatingIsland;

public partial class App : Application { }

public class Profile
{
    public string Name { get; set; } = "Default";
    public string Font { get; set; } = "Segoe UI";
    public double Size { get; set; } = 14;
    public string C1 { get; set; } = "#4776E6";
    public string C2 { get; set; } = "#8E54E9";
    public string Text { get; set; } = "#FFFFFF";
    public bool Gradient { get; set; } = true;
    public double Corner { get; set; } = 22;
    public double Angle { get; set; } = 45;
    public bool Animate { get; set; } = true;
    public string Gif { get; set; } = "";
}

public class AppItem
{
    public string Name { get; set; } = "";
    public string Path { get; set; } = "";
    public List<AppItem> Items { get; set; }   // не null — это папка с приложениями
}

public class Config
{
    public string Lang { get; set; } = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName == "ru" ? "ru" : "en";
    public int Active { get; set; }
    public bool Hud { get; set; } = true;            // столбик показателей в играх
    public bool HudAlways { get; set; }              // ...и вне игр
    public string HudSide { get; set; } = "left";
    public bool HudFps { get; set; } = true;
    public bool HudCpuLoad { get; set; } = true;
    public bool HudCpuTemp { get; set; } = true;
    public bool HudGpuLoad { get; set; } = true;
    public bool HudGpuTemp { get; set; } = true;
    public string City { get; set; } = "";
    public string CityKey { get; set; } = "";
    public double Lat { get; set; }
    public double Lon { get; set; }
    public double? Temp { get; set; }
    public int WCode { get; set; }
    public List<Profile> Profiles { get; set; } = new() { new Profile() };
    public List<AppItem> Apps { get; set; } = new();

    public static bool NoSave;   // true после импорта, чтобы старые данные не затёрли импортированные
    public static readonly string DataDir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FloatingIsland");
    static string FilePath => System.IO.Path.Combine(DataDir, "config.json");
    static string Mirror => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "FloatingIsland", "config-backup.json");
    static readonly JsonSerializerOptions Opt = new() { WriteIndented = true };

    public static Config Load()
    {
        foreach (var f in new[] { FilePath, FilePath + ".bak", Mirror })   // основной файл → прошлая версия → копия в «Документах»
        {
            try
            {
                var c = JsonSerializer.Deserialize<Config>(File.ReadAllText(f));
                if (c != null && c.Profiles.Count > 0) { c.Active = Math.Clamp(c.Active, 0, c.Profiles.Count - 1); return c; }
            }
            catch { }
        }
        var n = new Config(); bool ru = n.Lang == "ru";
        n.Apps = new()
        {
            new() { Name = ru ? "Проводник" : "Explorer", Path = "explorer.exe" },
            new() { Name = ru ? "Калькулятор" : "Calculator", Path = "calc.exe" },
            new() { Name = ru ? "Блокнот" : "Notepad", Path = "notepad.exe" },
            new() { Name = ru ? "Диспетчер задач" : "Task Manager", Path = "taskmgr.exe" },
            new() { Name = ru ? "Параметры" : "Settings", Path = "ms-settings:" },
        };
        return n;
    }

    // Пишем во временный файл и подменяем: сбой посреди записи не испортит настройки. Прошлая версия остаётся в .bak.
    public void Save()
    {
        if (NoSave) return;
        try
        {
            Directory.CreateDirectory(DataDir);
            var json = JsonSerializer.Serialize(this, Opt);
            var tmp = FilePath + ".tmp";
            File.WriteAllText(tmp, json);
            if (File.Exists(FilePath)) File.Replace(tmp, FilePath, FilePath + ".bak"); else File.Move(tmp, FilePath);
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(Mirror)!);
            File.WriteAllText(Mirror, json);
        }
        catch { }
    }

    // Выбранную гифку копируем в папку данных: профиль не сломается, если исходный файл удалят или переместят.
    public static string ImportGif(string src)
    {
        var dir = System.IO.Path.Combine(DataDir, "gifs"); Directory.CreateDirectory(dir);
        var name = Guid.NewGuid().ToString("N") + ".gif";
        File.Copy(src, System.IO.Path.Combine(dir, name)); return "gifs/" + name;
    }
    public static string ResolveGif(string g) =>
        string.IsNullOrEmpty(g) ? "" : System.IO.Path.IsPathRooted(g) ? g : System.IO.Path.Combine(DataDir, g.Replace('/', '\\'));

    public void Export(string path)
    {
        Save(); if (File.Exists(path)) File.Delete(path);
        System.IO.Compression.ZipFile.CreateFromDirectory(DataDir, path);
    }
    public static void Import(string path)
    {
        NoSave = true; Directory.CreateDirectory(DataDir);
        System.IO.Compression.ZipFile.ExtractToDirectory(path, DataDir, true);
    }
}


// CPU/GPU нагрузка и температуры (LibreHardwareMonitor). Опрос только когда нужно.
// Open() и Update() тяжёлые (загрузка драйвера, чтение MSR/NVML: от десятков до сотен мс), поэтому работают в фоне,
// а не в UI-потоке — иначе анимация острова рвалась в момент опроса.
public class Stats
{
    Computer pc;
    int running;
    public float CpuLoad = float.NaN, CpuTemp = float.NaN, GpuLoad = float.NaN, GpuTemp = float.NaN;

    static bool IsGpu(IHardware h) => h.HardwareType is HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel;

    // Если прошлый опрос ещё идёт — новый не запускается. done вызывается из фонового потока.
    public void UpdateAsync(Action done = null)
    {
        if (Interlocked.Exchange(ref running, 1) == 1) return;
        Task.Run(() =>
        {
            try { Update(); } catch { }
            finally { Volatile.Write(ref running, 0); }
            done?.Invoke();
        });
    }

    public void Close() { try { pc?.Close(); } catch { } }

    void Update()
    {
        if (pc == null)
        {
            var c = new Computer { IsCpuEnabled = true, IsGpuEnabled = true };
            try { c.Open(); } catch { }
            pc = c;
        }
        bool dgpu = pc.Hardware.Any(h => h.HardwareType is HardwareType.GpuNvidia or HardwareType.GpuAmd);
        foreach (var hw in pc.Hardware)
        {
            bool cpu = hw.HardwareType == HardwareType.Cpu;
            if (!cpu && (!IsGpu(hw) || (dgpu && hw.HardwareType == HardwareType.GpuIntel))) continue;
            hw.Update();
            foreach (var s in hw.Sensors)
            {
                if (s.Value is not float v) continue;
                var n = s.Name;
                if (s.SensorType == SensorType.Load && (n == "CPU Total" || n == "GPU Core"))
                { if (cpu) CpuLoad = v; else GpuLoad = v; }
                else if (s.SensorType == SensorType.Temperature &&
                         (cpu ? (n.Contains("Package") || n.Contains("Tctl") || n.Contains("Average")) : n == "GPU Core"))
                { if (cpu) CpuTemp = v; else GpuTemp = v; }
            }
        }
    }
}

// FPS через ETW (события Present из DXGI) — как в PresentMon. Нужны права администратора.
public class Fps
{
    uint pid; int head; double shown;
    TraceEventSession session;
    readonly long[] ring = new long[2048];   // метки времени последних кадров
    static readonly Guid Dxgi = new("CA11C036-0102-4A2D-A6AD-F03CFED5D3C9");

    public uint Pid
    {
        get => pid;
        set { if (pid != value) { pid = value; Array.Clear(ring); head = 0; shown = 0; } }
    }

    public void Start() => Task.Run(() =>
    {
        try
        {
            using var s = new TraceEventSession("FloatingIslandFps");
            session = s;
            s.EnableProvider(Dxgi);
            s.Source.AllEvents += e =>
            {
                if (e.ProviderGuid == Dxgi && (int)e.ID == 42 && e.ProcessID == (int)pid)
                    ring[head++ & 2047] = System.Diagnostics.Stopwatch.GetTimestamp();
            };
            s.Source.Process();
        }
        catch { }
    });

    // ETW-сессия живёт в системе, пока её не остановят, — даже после закрытия программы. Останавливаем при выходе.
    public void Stop() { try { session?.Dispose(); } catch { } }

    // Плавный FPS: кадры за последнюю секунду (скользящее окно) + мягкое сглаживание, чтобы цифра не прыгала.
    public int Read()
    {
        long from = System.Diagnostics.Stopwatch.GetTimestamp() - System.Diagnostics.Stopwatch.Frequency;
        int n = 0; foreach (var t in ring) if (t >= from) n++;
        shown = shown == 0 ? n : shown + (n - shown) * 0.35;
        return (int)Math.Round(shown);
    }
}
