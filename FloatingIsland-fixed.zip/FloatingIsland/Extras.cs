using System.Diagnostics;
using System.IO;
using System.Security;
using System.Text;

namespace FloatingIsland;

public static class Loc
{
    static readonly Dictionary<string, (string ru, string en)> D = new()
    {
        ["settings"] = ("Настройки", "Settings"), ["lang"] = ("Язык", "Language"), ["profile"] = ("Профили", "Profiles"),
        ["del"] = ("Удалить", "Delete"), ["name"] = ("Название профиля", "Profile name"),
        ["themes"] = ("Готовые темы", "Themes"), ["colors"] = ("Цвета и градиент", "Colors & gradient"),
        ["c1"] = ("Фон 1", "Background 1"), ["c2"] = ("Фон 2", "Background 2"), ["text"] = ("Текст", "Text"),
        ["grad"] = ("Градиент", "Gradient"), ["anim"] = ("Анимация", "Animated"), ["angle"] = ("Угол градиента", "Gradient angle"),
        ["font"] = ("Шрифт", "Font"), ["size"] = ("Размер шрифта", "Font size"), ["corner"] = ("Скругление", "Corner radius"),
        ["gif"] = ("Гифка", "GIF"), ["pick"] = ("Выбрать…", "Choose…"), ["clear"] = ("Убрать", "Clear"),
        ["gifhint"] = ("Можно перетащить .gif или .exe прямо на островок", "You can drop a .gif or .exe onto the island"),
        ["weather"] = ("Погода", "Weather"), ["city"] = ("Город, например: Москва", "City, e.g. London"),
        ["system"] = ("Система", "System"), ["autostart"] = ("Запускать вместе с Windows", "Start with Windows"),
        ["hotkey"] = ("Ctrl+Alt+I — открыть/закрыть островок (и в игре)\nCtrl+Alt+H — показать/скрыть островок и столбик", "Ctrl+Alt+I — open/close the island (in games too)\nCtrl+Alt+H — show/hide the island and the stats bar"),
        ["hudcard"] = ("Столбик показателей", "Stats bar"),
        ["fps"] = ("FPS", "FPS"), ["cpul"] = ("Нагрузка CPU", "CPU load"), ["cput"] = ("Температура CPU", "CPU temp"),
        ["gpul"] = ("Нагрузка GPU", "GPU load"), ["gput"] = ("Температура GPU", "GPU temp"),
        ["side"] = ("Сторона экрана", "Screen side"), ["left"] = ("Слева", "Left"), ["right"] = ("Справа", "Right"),
        ["hudgame"] = ("Показывать в играх", "Show in games"), ["hudalways"] = ("Показывать всегда", "Always show"),
        ["foldername"] = ("Папка", "Folder"), ["rename"] = ("Переименовать", "Rename"),
        ["dissolve"] = ("Разобрать папку", "Dissolve folder"), ["moveout"] = ("Вынуть из папки", "Move out of folder"),
        ["data"] = ("Данные и резервная копия", "Data & backup"),
        ["datahint"] = ("Настройки хранятся в AppData и переживают переустановку программы. Копия лежит в «Документах». Для переноса на другой ПК — экспорт.",
                        "Settings live in AppData and survive reinstalling the app. A copy is kept in Documents. Use export to move them to another PC."),
        ["export"] = ("Экспорт", "Export"), ["import"] = ("Импорт", "Import"), ["folder"] = ("Папка данных", "Data folder"),
        ["showhide"] = ("Показать/скрыть", "Show/Hide"), ["openclose"] = ("Открыть/закрыть", "Open/close"), ["exit"] = ("Выход", "Exit"),
    };
    public static string T(string lang, string k) => lang == "ru" ? D[k].ru : D[k].en;
}

public record Preset(string C1, string C2, string Text, bool Gradient = true);
public static class Presets
{
    public static readonly Preset[] All =
    {
        new("#4776E6", "#8E54E9", "#FFFFFF"), new("#FF512F", "#DD2476", "#FFFFFF"), new("#00C6FF", "#0072FF", "#FFFFFF"),
        new("#11998E", "#38EF7D", "#06281F"), new("#F857A6", "#FF5858", "#FFFFFF"), new("#1E1E2E", "#45475A", "#F5F5F5"),
        new("#111111", "#111111", "#FFFFFF", false),
    };
}

// Автозапуск через планировщик: так программа с правами администратора стартует без окна UAC
// и не отключается на батарее (в отличие от обычного schtasks /create).
public static class Autostart
{
    const string Name = "FloatingIsland";
    public static bool IsOn() => Run($"/query /tn {Name}") == 0;

    public static void Set(bool on)
    {
        if (!on) { Run($"/delete /tn {Name} /f"); return; }
        var xml = $@"<?xml version=""1.0"" encoding=""UTF-16""?>
<Task xmlns=""http://schemas.microsoft.com/windows/2004/02/mit/task"">
  <Triggers><LogonTrigger><Enabled>true</Enabled></LogonTrigger></Triggers>
  <Principals><Principal id=""A""><LogonType>InteractiveToken</LogonType><RunLevel>HighestAvailable</RunLevel></Principal></Principals>
  <Settings><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries><StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><ExecutionTimeLimit>PT0S</ExecutionTimeLimit></Settings>
  <Actions Context=""A""><Exec><Command>{SecurityElement.Escape(Environment.ProcessPath)}</Command></Exec></Actions>
</Task>";
        var f = Path.Combine(Path.GetTempPath(), "fi_task.xml");
        File.WriteAllText(f, xml, Encoding.Unicode);
        Run($"/create /tn {Name} /xml \"{f}\" /f");
        File.Delete(f);
    }

    static int Run(string args)
    {
        try
        {
            using var p = Process.Start(new ProcessStartInfo("schtasks", args) { CreateNoWindow = true, UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true });
            p.WaitForExit(8000); return p.ExitCode;
        }
        catch { return -1; }
    }
}
