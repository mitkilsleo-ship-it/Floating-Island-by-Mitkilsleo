using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace FloatingIsland;

// Окно настроек оформлено так же, как островок: тот же градиент, шрифт, цвета, анимации.
public class SettingsWindow : Window
{
    static readonly List<FontFamily> AllFonts = Fonts.SystemFontFamilies.OrderBy(x => x.Source).ToList();

    readonly MainWindow m;
    readonly List<Action> sync = new();
    readonly StackPanel page = new() { Margin = new Thickness(18, 0, 18, 18) };
    readonly TextBlock title = new() { FontSize = 18, FontWeight = FontWeights.Bold, VerticalAlignment = VerticalAlignment.Center };
    readonly bool autoOn = Autostart.IsOn();
    RotateTransform rot;
    bool closing;
    readonly Border frame = new()
    {
        Margin = new Thickness(10), CornerRadius = new CornerRadius(22), ClipToBounds = true, Opacity = 0,
        BorderThickness = new Thickness(1), BorderBrush = new SolidColorBrush(Color.FromArgb(0x40, 255, 255, 255)),
        RenderTransformOrigin = new Point(.5, 0),
    };
    bool first = true;
    Config cfg => m.Cfg;
    Profile P => cfg.Profiles[cfg.Active];
    string Tr(string k) => Loc.T(cfg.Lang, k);
    static TimeSpan Ms(int n) => TimeSpan.FromMilliseconds(n);
    void Rebuild() => Dispatcher.BeginInvoke(new Action(Build));

    public SettingsWindow(MainWindow main)
    {
        m = main;
        WindowStyle = WindowStyle.None; ResizeMode = ResizeMode.NoResize; AllowsTransparency = true; Background = Brushes.Transparent;
        Width = 460; Height = Math.Min(740, SystemParameters.WorkArea.Height - 20);
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        SetResourceReference(ForegroundProperty, "Fg");

        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition());
        var bar = new Grid { Background = Brushes.Transparent, Margin = new Thickness(18, 12, 12, 8) };
        bar.MouseLeftButtonDown += (_, e) => { if (e.ButtonState == MouseButtonState.Pressed) DragMove(); };
        var x = new Button { Content = "✕", HorizontalAlignment = HorizontalAlignment.Right, Padding = new Thickness(12, 4, 12, 4) };
        x.Click += (_, _) => CloseAnimated();
        bar.Children.Add(title); bar.Children.Add(x);
        var sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Hidden, Content = page };
        Grid.SetRow(sv, 1); root.Children.Add(bar); root.Children.Add(sv);
        frame.Child = root; Content = frame; Loaded += (_, _) => Open();

        m.Applied += Skin; Skin(); Build();
        Closing += (_, _) => cfg.Save();
        Closed += (_, _) => m.Applied -= Skin;
    }

    // Окно «выпрыгивает» сверху с лёгким пружинящим эффектом и плавно гаснет при закрытии.
    void Open()
    {
        var sc = new ScaleTransform(.88, .88); var tr = new TranslateTransform(0, -24);
        frame.RenderTransform = new TransformGroup { Children = { sc, tr } };
        Look.FadeIn(frame, 0, 260);
        var pop = new BackEase { Amplitude = .3, EasingMode = EasingMode.EaseOut };
        sc.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(1, Ms(420)) { EasingFunction = pop });
        sc.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(1, Ms(420)) { EasingFunction = pop });
        tr.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(0, Ms(420)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
    }

    void CloseAnimated()
    {
        if (closing) return; closing = true;
        var a = new DoubleAnimation(0, Ms(200)); a.Completed += (_, _) => Close();
        frame.BeginAnimation(OpacityProperty, a);
        if (frame.RenderTransform is TransformGroup g && g.Children[0] is ScaleTransform sc)
        {
            var d = new DoubleAnimation(.92, Ms(200));
            sc.BeginAnimation(ScaleTransform.ScaleXProperty, d); sc.BeginAnimation(ScaleTransform.ScaleYProperty, d);
        }
    }

    void Skin()
    {
        var p = P; frame.Background = Look.Bg(p, out rot); Look.Spin(rot, p.Angle, p.Animate);
        FontFamily = new FontFamily(p.Font); FontSize = p.Size;
    }

    void Reveal(UIElement el, int i)
    {
        var tt = new TranslateTransform(0, 16); el.RenderTransform = tt;
        Look.FadeIn(el, 150 + 70 * i, 320);
        tt.BeginAnimation(TranslateTransform.YProperty,
            new DoubleAnimation(0, Ms(380)) { BeginTime = Ms(150 + 70 * i), EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
    }

    void Build()
    {
        sync.Clear(); page.Children.Clear(); title.Text = Tr("settings");
        int n = 0; var p = P;

        // ---- помощники ----
        void Card(string head, params UIElement[] items)
        {
            var sp = new StackPanel();
            if (head != null) sp.Children.Add(new TextBlock { Text = head, FontWeight = FontWeights.SemiBold, Opacity = .75, Margin = new Thickness(0, 0, 0, 8) });
            foreach (var i in items) sp.Children.Add(i);
            var b = new Border { Child = sp, CornerRadius = new CornerRadius(14), Padding = new Thickness(14), Margin = new Thickness(0, 0, 0, 10) };
            b.SetResourceReference(Border.BackgroundProperty, "Card");
            page.Children.Add(b); if (first) Reveal(b, n++);
        }
        Button Btn(string t, Action a) { var b = new Button { Content = t, Padding = new Thickness(14, 6, 14, 6) }; b.Click += (_, _) => a(); return b; }
        Panel Wrap(params UIElement[] c) { var w = new WrapPanel(); foreach (var x in c) w.Children.Add(x); return w; }
        RadioButton Chip(string text, bool on, string group, Action pick)
        {
            var r = new RadioButton { Content = text, IsChecked = on, GroupName = group, Style = (Style)FindResource("Chip") };
            r.Checked += (_, _) => pick(); return r;
        }
        Panel Sld(string label, double min, double max, double v, Action<double> on)
        {
            var sl = new Slider { Minimum = min, Maximum = max, Value = v, AutoToolTipPlacement = System.Windows.Controls.Primitives.AutoToolTipPlacement.TopLeft, AutoToolTipPrecision = 0 };
            sl.ValueChanged += (_, e) => { on(e.NewValue); m.Apply(); };
            var sp = new StackPanel(); sp.Children.Add(new TextBlock { Text = label, Margin = new Thickness(0, 4, 0, 0) }); sp.Children.Add(sl); return sp;
        }
        Button ColorBtn(string label, Func<string> get, Action<string> set)
        {
            var sw = new Border { Width = 22, Height = 22, CornerRadius = new CornerRadius(11), BorderBrush = Brushes.Gray, BorderThickness = new Thickness(1), Margin = new Thickness(0, 0, 8, 0) };
            void Paint() => sw.Background = new SolidColorBrush(Look.C(get()));
            Paint(); sync.Add(Paint);
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            sp.Children.Add(sw); sp.Children.Add(new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center });
            var b = new Button { Content = sp, Padding = new Thickness(10, 6, 14, 6) };
            b.Click += (_, _) =>
            {
                using var d = new System.Windows.Forms.ColorDialog { FullOpen = true, Color = System.Drawing.ColorTranslator.FromHtml(get()) };
                if (d.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
                set($"#{d.Color.R:X2}{d.Color.G:X2}{d.Color.B:X2}"); Paint(); m.Apply();
            };
            return b;
        }
        Border Swatch(Preset pr)
        {
            var sc = new ScaleTransform(1, 1);
            var b = new Border
            {
                Width = 58, Height = 34, CornerRadius = new CornerRadius(10), Margin = new Thickness(0, 0, 8, 8), Cursor = Cursors.Hand,
                RenderTransformOrigin = new Point(.5, .5), RenderTransform = sc,
                Background = new LinearGradientBrush(Look.C(pr.C1), Look.C(pr.C2), 45),
                Child = new TextBlock { Text = "Aa", FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Foreground = new SolidColorBrush(Look.C(pr.Text)) },
            };
            void To(double v) { var a = new DoubleAnimation(v, Ms(120)); sc.BeginAnimation(ScaleTransform.ScaleXProperty, a); sc.BeginAnimation(ScaleTransform.ScaleYProperty, a); }
            b.MouseEnter += (_, _) => To(1.1); b.MouseLeave += (_, _) => To(1);
            b.MouseLeftButtonUp += (_, _) => { P.C1 = pr.C1; P.C2 = pr.C2; P.Text = pr.Text; P.Gradient = pr.Gradient; m.Apply(); foreach (var a in sync) a(); };
            return b;
        }

        // ---- язык и профили ----
        var chips = new WrapPanel();
        for (int i = 0; i < cfg.Profiles.Count; i++)
        {
            int idx = i;
            chips.Children.Add(Chip(cfg.Profiles[i].Name, i == cfg.Active, "prof", () => { cfg.Active = idx; cfg.Save(); m.Apply(); Rebuild(); }));
        }
        var dup = Btn("+", () =>
        {
            var c = System.Text.Json.JsonSerializer.Deserialize<Profile>(System.Text.Json.JsonSerializer.Serialize(P))!;
            int k = 2; while (cfg.Profiles.Any(x => x.Name == $"{P.Name} {k}")) k++;
            c.Name = $"{P.Name} {k}"; cfg.Profiles.Add(c); cfg.Active = cfg.Profiles.Count - 1; cfg.Save(); m.Apply(); Rebuild();
        });
        dup.Margin = new Thickness(0, 0, 0, 6); chips.Children.Add(dup);
        var nm = new TextBox { Text = p.Name };
        nm.LostFocus += (_, _) =>
        {
            var t = nm.Text.Trim();
            if (t.Length == 0 || t == P.Name || cfg.Profiles.Any(x => x.Name == t)) { nm.Text = P.Name; return; }
            P.Name = t; cfg.Save(); Rebuild();
        };
        var del = Btn(Tr("del"), () =>
        {
            if (cfg.Profiles.Count < 2) return;
            cfg.Profiles.RemoveAt(cfg.Active); cfg.Active = 0; cfg.Save(); m.Apply(); Rebuild();
        });
        var dock = new DockPanel(); DockPanel.SetDock(del, Dock.Right); dock.Children.Add(del); dock.Children.Add(nm);
        Card(Tr("lang"), Wrap(
            Chip("Русский", cfg.Lang == "ru", "lang", () => { cfg.Lang = "ru"; cfg.Save(); m.Relocalize(); Rebuild(); }),
            Chip("English", cfg.Lang == "en", "lang", () => { cfg.Lang = "en"; cfg.Save(); m.Relocalize(); Rebuild(); })));
        Card(Tr("profile"), chips, dock);

        // ---- оформление ----
        var themes = new WrapPanel();
        foreach (var pr in Presets.All) themes.Children.Add(Swatch(pr));
        Card(Tr("themes"), themes);

        var gr = new CheckBox { Content = Tr("grad"), IsChecked = p.Gradient };
        gr.Click += (_, _) => { P.Gradient = gr.IsChecked == true; m.Apply(); };
        sync.Add(() => gr.IsChecked = P.Gradient);
        var an = new CheckBox { Content = Tr("anim"), IsChecked = p.Animate };
        an.Click += (_, _) => { P.Animate = an.IsChecked == true; m.Apply(); };
        Card(Tr("colors"),
            Wrap(ColorBtn(Tr("c1"), () => P.C1, v => P.C1 = v), ColorBtn(Tr("c2"), () => P.C2, v => P.C2 = v), ColorBtn(Tr("text"), () => P.Text, v => P.Text = v)),
            Wrap(gr, an),
            Sld(Tr("angle"), 0, 360, p.Angle, v => P.Angle = v));

        var fl = new ListBox { Height = 150 };
        foreach (var f in AllFonts)
        {
            var it = new ListBoxItem { Content = f.Source, FontFamily = f };
            fl.Items.Add(it); if (f.Source == p.Font) fl.SelectedItem = it;
        }
        fl.SelectionChanged += (_, _) => { if (fl.SelectedItem is ListBoxItem li) { P.Font = (string)li.Content; m.Apply(); } };
        fl.Loaded += (_, _) => { if (fl.SelectedItem != null) fl.ScrollIntoView(fl.SelectedItem); };
        Card(Tr("font"), fl, Sld(Tr("size"), 10, 22, p.Size, v => P.Size = v), Sld(Tr("corner"), 8, 30, p.Corner, v => P.Corner = v));

        // ---- гифка и погода ----
        Card(Tr("gif"),
            Wrap(Btn(Tr("pick"), () =>
            {
                var d = new Microsoft.Win32.OpenFileDialog { Filter = "GIF|*.gif" };
                if (d.ShowDialog(this) == true) { P.Gif = Config.ImportGif(d.FileName); cfg.Save(); m.Apply(); }
            }), Btn(Tr("clear"), () => { P.Gif = ""; cfg.Save(); m.Apply(); })),
            new TextBlock { Text = Tr("gifhint"), Opacity = .65, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 4, 0, 0) });

        var city = new TextBox { Text = cfg.City };
        void ApplyCity()
        {
            var t = city.Text.Trim(); if (t == cfg.City) return;
            cfg.City = t; cfg.CityKey = ""; cfg.Temp = null; cfg.Save(); m.RefreshWeather();
        }
        city.LostFocus += (_, _) => ApplyCity();
        city.KeyDown += (_, e) => { if (e.Key == Key.Enter) { Keyboard.ClearFocus(); ApplyCity(); } };
        Card(Tr("weather"), new TextBlock { Text = Tr("city"), Opacity = .65, Margin = new Thickness(0, 0, 0, 4) }, city);

        // ---- столбик показателей ----
        CheckBox Chk(string text, bool v, Action<bool> on)
        {
            var c = new CheckBox { Content = text, IsChecked = v };
            c.Click += (_, _) => { on(c.IsChecked == true); cfg.Save(); m.HudSettingChanged(); };
            return c;
        }
        Card(Tr("hudcard"),
            Wrap(Chk(Tr("fps"), cfg.HudFps, v => cfg.HudFps = v), Chk(Tr("cpul"), cfg.HudCpuLoad, v => cfg.HudCpuLoad = v),
                 Chk(Tr("cput"), cfg.HudCpuTemp, v => cfg.HudCpuTemp = v), Chk(Tr("gpul"), cfg.HudGpuLoad, v => cfg.HudGpuLoad = v),
                 Chk(Tr("gput"), cfg.HudGpuTemp, v => cfg.HudGpuTemp = v)),
            new TextBlock { Text = Tr("side"), Opacity = .65, Margin = new Thickness(0, 8, 0, 4) },
            Wrap(Chip(Tr("left"), cfg.HudSide != "right", "side", () => { cfg.HudSide = "left"; cfg.Save(); m.HudSettingChanged(); }),
                 Chip(Tr("right"), cfg.HudSide == "right", "side", () => { cfg.HudSide = "right"; cfg.Save(); m.HudSettingChanged(); })),
            Wrap(Chk(Tr("hudgame"), cfg.Hud, v => cfg.Hud = v), Chk(Tr("hudalways"), cfg.HudAlways, v => cfg.HudAlways = v)));

        // ---- система и данные ----
        var au = new CheckBox { Content = Tr("autostart"), IsChecked = autoOn };
        au.Click += (_, _) => Autostart.Set(au.IsChecked == true);
        Card(Tr("system"), au, new TextBlock { Text = Tr("hotkey"), Opacity = .65, Margin = new Thickness(0, 6, 0, 0) });

        Card(Tr("data"),
            new TextBlock { Text = Tr("datahint"), Opacity = .65, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 8) },
            Wrap(Btn(Tr("export"), () =>
            {
                var d = new Microsoft.Win32.SaveFileDialog { Filter = "ZIP|*.zip", FileName = "FloatingIsland-backup.zip" };
                if (d.ShowDialog(this) == true) cfg.Export(d.FileName);
            }), Btn(Tr("import"), () =>
            {
                var d = new Microsoft.Win32.OpenFileDialog { Filter = "ZIP|*.zip" };
                if (d.ShowDialog(this) != true) return;
                Config.Import(d.FileName);   // после импорта перезапускаем программу, чтобы подхватить данные
                Process.Start(new ProcessStartInfo(Environment.ProcessPath!) { UseShellExecute = true });
                Application.Current.Shutdown();
            }), Btn(Tr("folder"), () => Process.Start("explorer.exe", Config.DataDir)), Btn(Tr("exit"), () => Application.Current.Shutdown())));

        first = false;
    }
}
